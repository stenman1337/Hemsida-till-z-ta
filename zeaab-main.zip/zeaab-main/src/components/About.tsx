import { CheckCircle2, Shield, Users, Award } from "lucide-react";

const values = [
  {
    icon: Shield,
    title: "Säkerhet först",
    description: "Alla installationer utförs enligt gällande föreskrifter och med högsta säkerhetsstandard.",
  },
  {
    icon: Users,
    title: "Kundnöjdhet",
    description: "Vi lyssnar på dina behov och levererar lösningar som överträffar förväntningarna.",
  },
  {
    icon: Award,
    title: "Kvalitet",
    description: "Noggrannhet och professionalitet genomsyrar allt vi gör, oavsett projektets storlek.",
  },
];

const About = () => {
  return (
    <section id="om-oss" className="py-20 md:py-32">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Text content */}
          <div>
            <p className="text-primary font-semibold mb-3">Om oss</p>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6">
              Din lokala partner för el och automation i Sundsvall
            </h2>
            <p className="text-lg text-muted-foreground mb-6">
              Zätterqvist El och Automation AB drivs av William Zätterqvist och är ett elföretag 
              baserat i Sundsvall. Vi arbetar med privatpersoner, företag och industrier i hela 
              Västernorrland och erbjuder helhetslösningar inom el och automation.
            </p>
            <p className="text-muted-foreground mb-8">
              Med engagemang för kvalitet och personlig service tar vi oss an projekt i alla storlekar. 
              Från mindre heminstallationer till större industriprojekt – du får alltid direkt kontakt 
              med ägaren och samma noggrannhet och professionalitet i varje uppdrag.
            </p>

            {/* Checklist */}
            <ul className="space-y-4">
              {[
                "Auktoriserade och certifierade elektriker",
                "Lokalt förankrade i Sundsvall sedan start",
                "Flexibla lösningar anpassade efter dina behov",
                "Snabb och pålitlig service",
              ].map((item) => (
                <li key={item} className="flex items-start gap-3">
                  <CheckCircle2 className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                  <span className="text-foreground">{item}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Values cards */}
          <div className="space-y-6">
            {values.map((value, index) => (
              <div 
                key={value.title}
                className="flex gap-4 p-6 rounded-xl bg-card border hover:shadow-md transition-shadow"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <value.icon className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground mb-1">{value.title}</h3>
                  <p className="text-muted-foreground text-sm">{value.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
