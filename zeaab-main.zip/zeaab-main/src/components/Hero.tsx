import { Phone, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

const Hero = () => {
  return (
    <section id="hem" className="relative min-h-screen flex items-center pt-20">
      {/* Background with gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-accent via-background to-background" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-primary/10 via-transparent to-transparent" />
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary font-medium text-sm mb-6">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
            </span>
            Din lokala elektriker i Sundsvall
          </div>

          {/* Main heading */}
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-foreground leading-tight mb-6">
            Pålitliga elinstallationer med{" "}
            <span className="text-primary">kvalitet & säkerhet</span> i fokus
          </h1>

          {/* Subheading */}
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-8">
            Vi på Zätterqvist El och Automation erbjuder professionella eltjänster för privatpersoner, 
            företag och industri i hela Västernorrland. Med gedigen erfarenhet och fokus på kundnöjdhet 
            garanterar vi arbete av högsta kvalitet.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button size="lg" asChild className="text-lg px-8 py-6">
              <a href="#kontakt">
                Kontakta oss
                <ArrowRight className="ml-2 h-5 w-5" />
              </a>
            </Button>
            <Button size="lg" variant="outline" asChild className="text-lg px-8 py-6">
              <a href="tel:0768076622">
                <Phone className="mr-2 h-5 w-5" />
                Ring 076-807 66 22
              </a>
            </Button>
          </div>

          {/* Trust indicators */}
          <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <div className="p-6 rounded-xl bg-card border shadow-sm">
              <div className="text-3xl font-bold text-primary mb-2">Lokal</div>
              <div className="text-muted-foreground">Verksamma i Sundsvall & Västernorrland</div>
            </div>
            <div className="p-6 rounded-xl bg-card border shadow-sm">
              <div className="text-3xl font-bold text-primary mb-2">Certifierad</div>
              <div className="text-muted-foreground">Auktoriserade elektriker</div>
            </div>
            <div className="p-6 rounded-xl bg-card border shadow-sm">
              <div className="text-3xl font-bold text-primary mb-2">Kvalitet</div>
              <div className="text-muted-foreground">Noggrannhet i varje projekt</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
