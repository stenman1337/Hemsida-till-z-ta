import { Phone, MapPin, Mail } from "lucide-react";
import logo from "@/assets/logo.png";

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-foreground text-background py-12 md:py-16">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          {/* Company info */}
          <div>
            <img 
              src={logo} 
              alt="Zätterqvist El och Automation AB" 
              className="h-10 w-auto mb-4 brightness-0 invert"
            />
            <p className="text-background/70 text-sm">
              Professionella eltjänster för privatpersoner, företag och industri i Sundsvall och Västernorrland.
            </p>
          </div>

          {/* Quick links */}
          <div>
            <h4 className="font-semibold text-lg mb-4">Snabblänkar</h4>
            <ul className="space-y-2">
              <li>
                <a href="#tjanster" className="text-background/70 hover:text-background transition-colors">
                  Tjänster
                </a>
              </li>
              <li>
                <a href="#om-oss" className="text-background/70 hover:text-background transition-colors">
                  Om oss
                </a>
              </li>
              <li>
                <a href="#kontakt" className="text-background/70 hover:text-background transition-colors">
                  Kontakt
                </a>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-semibold text-lg mb-4">Kontakt</h4>
            <ul className="space-y-3">
              <li>
                <a 
                  href="tel:0768076622" 
                  className="flex items-center gap-2 text-background/70 hover:text-background transition-colors"
                >
                  <Phone className="h-4 w-4" />
                  076-807 66 22
                </a>
              </li>
              <li>
                <a 
                  href="mailto:William@zeaab.se" 
                  className="flex items-center gap-2 text-background/70 hover:text-background transition-colors"
                >
                  <Mail className="h-4 w-4" />
                  William@zeaab.se
                </a>
              </li>
              <li className="flex items-start gap-2 text-background/70">
                <MapPin className="h-4 w-4 mt-0.5 flex-shrink-0" />
                <span>
                  Vikingavägen 51D<br />
                  857 42 Sundsvall
                </span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-8 border-t border-background/20 text-center text-sm text-background/60">
          <p>© {currentYear} Zätterqvist El och Automation AB. Alla rättigheter förbehållna.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
