import { Zap, Wrench, Cpu, Building2, ArrowRight } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const services = [
  {
    icon: Zap,
    title: "Elinstallationer",
    description: "Kompletta elinstallationer för både privat och företag. Vi hanterar allt från nya dragningar till ombyggnationer och renoveringar.",
    features: ["Nyinstallation", "Ombyggnation", "Renovering", "Belysning"],
  },
  {
    icon: Wrench,
    title: "Service & Felsökning",
    description: "Snabb och professionell felsökning när något går fel. Vi diagnostiserar problemet och åtgärdar det effektivt.",
    features: ["Akut felsökning", "Reparationer", "Underhåll", "Kontroller"],
  },
  {
    icon: Cpu,
    title: "Automation",
    description: "Moderna automationslösningar för hem och företag. Smarta system som förenklar din vardag och effektiviserar verksamheten.",
    features: ["Smarta hem", "Styrsystem", "Programmering", "Integration"],
  },
  {
    icon: Building2,
    title: "Industri & Fastighet",
    description: "Specialiserade lösningar för industri och fastighetsägare. Vi tar hand om era större projekt med samma noggrannhet.",
    features: ["Industriprojekt", "Fastighetsservice", "Stora anläggningar", "Periodisk kontroll"],
  },
];

const Services = () => {
  return (
    <section id="tjanster" className="py-20 md:py-32 bg-muted/30">
      <div className="container mx-auto px-4">
        {/* Section header */}
        <div className="max-w-3xl mx-auto text-center mb-16">
          <p className="text-primary font-semibold mb-3">Våra tjänster</p>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Helhetslösningar inom el och automation
          </h2>
          <p className="text-lg text-muted-foreground">
            Vi erbjuder ett brett utbud av eltjänster för att möta alla dina behov. 
            Oavsett projektets storlek levererar vi alltid med kvalitet i fokus.
          </p>
        </div>

        {/* Services grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8 max-w-5xl mx-auto">
          {services.map((service) => (
            <Card 
              key={service.title} 
              className="group hover:shadow-lg transition-all duration-300 hover:border-primary/50"
            >
              <CardHeader>
                <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                  <service.icon className="h-7 w-7 text-primary group-hover:text-primary-foreground transition-colors" />
                </div>
                <CardTitle className="text-xl">{service.title}</CardTitle>
                <CardDescription className="text-base">{service.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="grid grid-cols-2 gap-2">
                  {service.features.map((feature) => (
                    <li key={feature} className="flex items-center gap-2 text-sm text-muted-foreground">
                      <span className="w-1.5 h-1.5 rounded-full bg-primary flex-shrink-0" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* CTA */}
        <div className="text-center mt-12">
          <p className="text-muted-foreground mb-4">
            Behöver du hjälp med något annat? Vi anpassar oss efter dina behov.
          </p>
          <Button asChild variant="outline" size="lg">
            <a href="#kontakt">
              Beskriv ditt projekt
              <ArrowRight className="ml-2 h-4 w-4" />
            </a>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default Services;
